module.exports = {
    output: 'export',
    images: {
      remotePatterns: [
        {
          protocol: 'http',
          hostname: 'i.annihil.us',
        },
      ],
    },
  };
  